from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import os
import pandas as pd





def login_to_linkedin(username, password):
    # Logging into Linkedin
    driver = webdriver.Chrome()
    driver.get("https://www.linkedin.com/login")

    # Entering Information
    email_field = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.ID, "username"))
    )
    email_field.send_keys(username)

    password_field = driver.find_element(By.ID, "password")
    password_field.send_keys(password)
    password_field.submit()

    return driver

def send_connection_requests(driver, links):
    for link in links:
        driver.get(link)
        connect_xp = "//button[@class='artdeco-button artdeco-button--2 artdeco-button--primary ember-view pvs-profile-actions__action']"
        #Clicking the button
        time.sleep(5)
        connect_button = driver.find_element("xpath",connect_xp)
        connect_button.click()

        #Closing note prompt
        close_xp = "//button[@class='artdeco-modal__dismiss artdeco-button artdeco-button--circle artdeco-button--muted artdeco-button--2 artdeco-button--tertiary ember-view']"
        time.sleep(5)
        close = driver.find_element("xpath",close_xp)
        close.click()
        time.sleep(3)
        
def reading_in_links():
    
    excel_folder_name = "excel_connect"
    current_folder = os.getcwd()

# Get the current folder path
    excel_folder = os.path.join(current_folder, excel_folder_name)

# Get the list of Excel files in the folder
    excel_files = [file for file in os.listdir(excel_folder) if file.endswith(".xlsx")]

    if excel_files:

    # Fetch the first Excel file in the list

        first_excel_file = excel_files[0]

    # Construct the full file path
        excel_path = os.path.join(excel_folder, first_excel_file)
        
    #read the excel file
    df = pd.read_excel(excel_path)
    #Making into a list
    links = df.iloc[:, 0].to_list()
    return links


if __name__ == "__main__":
    # Get user input for email and password
    email = input("Enter your LinkedIn email/username: ")
    password = input("Enter your LinkedIn password: ")

    # Call the login function
    driver = login_to_linkedin(email, password)
    
    # Define the links for connections
    links = reading_in_links()

    # Define the links for connections
    #links = ["hhttps://www.linkedin.com/in/vaishnavi-ovekar-bb1702251/", "https://www.linkedin.com/in/chitranshi-shrivastava-877129230/"]

    # Call the send_connection_requests function
    send_connection_requests(driver, links)

    # Close the browser window after all connection requests have been sent
    driver.quit()






