# LinkedIn Connection Request Automation

This Python script automates sending connection requests on LinkedIn using Selenium. You can use this script to send connection requests to a list of LinkedIn profiles stored in an Excel file.

## Prerequisites

Before you begin, make sure you have the following requirements in place:
Python installed on your system.
Selenium Python library.
Chrome WebDriver installed and added to your system's PATH.
An Excel file with a list of LinkedIn profile links (URLs) to which you want to send connection requests.


Create a folder named "excel_connect" in the same directory as the script. Place your Excel files with LinkedIn profile links in this folder.

Update the excel_folder_name variable in the reading_in_links function to match the folder name where your Excel files are located.

Run the script by executing the following command in your terminal:

python linkedin_connection.py

Follow the on-screen prompts to enter your LinkedIn email/username and password.

The script will open a Chrome browser, log in to LinkedIn, and send connection requests to the profiles listed in your Excel file.

Once all connection requests are sent, the script will close the browser window.

